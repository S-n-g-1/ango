package main

import (
	"os"
	"path/filepath"
	"testing"
)

func write(t *testing.T, path string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte("label start\nend\n"), 0o644); err != nil {
		t.Fatal(err)
	}
}

func TestScanProjects(t *testing.T) {
	root := t.TempDir()
	write(t, filepath.Join(root, "zeta", "main.ango"))
	write(t, filepath.Join(root, "Alpha", "main.ango"))
	write(t, filepath.Join(root, "Alpha", "chapter1.ango"))
	write(t, filepath.Join(root, ".hidden", "main.ango")) // disembunyikan
	write(t, filepath.Join(root, "kosong", "readme.txt")) // tanpa .ango
	write(t, filepath.Join(root, "loose.ango"))           // bukan folder

	ps, err := scanProjects(root)
	if err != nil {
		t.Fatal(err)
	}
	if len(ps) != 2 || ps[0].name != "Alpha" || ps[1].name != "zeta" {
		t.Fatalf("got %+v, want [Alpha zeta]", ps)
	}
	if ps[0].files != 2 {
		t.Errorf("Alpha files = %d, want 2", ps[0].files)
	}
	if !filepath.IsAbs(ps[0].dir) {
		t.Errorf("dir should be absolute, got %q", ps[0].dir)
	}
}

func TestScanProjectsMissingRoot(t *testing.T) {
	if _, err := scanProjects(filepath.Join(t.TempDir(), "tidak-ada")); err == nil {
		t.Error("expected an error for a missing root")
	}
}

func TestFindAngoExplicit(t *testing.T) {
	dir := t.TempDir()
	bin := filepath.Join(dir, "ango")
	if err := os.WriteFile(bin, []byte("#!/bin/sh\n"), 0o755); err != nil {
		t.Fatal(err)
	}
	got, err := findAngo(bin)
	if err != nil || got != bin {
		t.Errorf("findAngo(%q) = %q, %v", bin, got, err)
	}
	if _, err := findAngo(filepath.Join(dir, "nope")); err == nil {
		t.Error("expected an error for a missing explicit path")
	}
}
