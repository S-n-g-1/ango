#!/bin/sh
# Membangun paket Linux: ango + ango-launcher + ango.sh + projects/
set -e
OUT=dist/ango-linux-amd64
rm -rf "$OUT"
mkdir -p "$OUT/projects"
go build -trimpath -ldflags "-s -w" -o "$OUT/ango" ./cmd/ango
go build -trimpath -ldflags "-s -w" -o "$OUT/ango-launcher" ./cmd/ango-launcher
cp -r examples/intro "$OUT/projects/intro"
printf '#!/bin/sh\ncd "$(dirname "$0")" && exec ./ango-launcher "$@"\n' > "$OUT/ango.sh"
chmod +x "$OUT/ango.sh"
tar -C dist -czf dist/ango-linux-amd64.tar.gz ango-linux-amd64
ls -lh "$OUT" dist/ango-linux-amd64.tar.gz
