// Command ango-launcher is a small graphical launcher for Ango stories,
// in the spirit of the Ren'Py launcher: it lists the projects found in a
// folder and runs the sibling `ango` binary on them (play, check, auto-test),
// showing the output in a log panel.
package main

import (
	"bufio"
	"bytes"
	"errors"
	"flag"
	"fmt"
	"image"
	"image/color"
	"io"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
	"github.com/hajimehoshi/ebiten/v2/text/v2"
	"golang.org/x/image/font/gofont/goregular"
)

const (
	winW, winH = 1100, 680
	faceSize   = 18
	lineH      = 24
	itemH      = 44

	infoX            = 392
	btnW, btnH       = 250, 42
	btnGapX, btnGapY = 16, 10
	btnTop           = 170
)

var (
	colBG    = color.NRGBA{20, 20, 32, 255}
	colPanel = color.NRGBA{30, 30, 50, 255}
	colItem  = color.NRGBA{44, 44, 74, 255}
	colSel   = color.NRGBA{70, 70, 140, 255}
	colBtn   = color.NRGBA{42, 42, 80, 255}
	colBtnHi = color.NRGBA{70, 70, 140, 255}
	colOff   = color.NRGBA{34, 34, 48, 255}
	colText  = color.NRGBA{255, 255, 255, 255}
	colDim   = color.NRGBA{150, 150, 175, 255}
	colOffTx = color.NRGBA{100, 100, 120, 255}

	listRect = image.Rect(24, 84, 364, 656)
	logRect  = image.Rect(392, 330, 1076, 656)
)

// ---- projects ----

type project struct {
	name  string
	dir   string // absolute
	files int    // number of .ango files directly inside
}

// scanProjects returns the sub-folders of root that contain at least one
// .ango file, sorted by name. Hidden folders are skipped.
func scanProjects(root string) ([]project, error) {
	entries, err := os.ReadDir(root)
	if err != nil {
		return nil, err
	}
	var out []project
	for _, e := range entries {
		if !e.IsDir() || strings.HasPrefix(e.Name(), ".") {
			continue
		}
		dir := filepath.Join(root, e.Name())
		n := countAngo(dir)
		if n == 0 {
			continue
		}
		abs, err := filepath.Abs(dir)
		if err != nil {
			abs = dir
		}
		out = append(out, project{name: e.Name(), dir: abs, files: n})
	}
	sort.Slice(out, func(i, j int) bool {
		return strings.ToLower(out[i].name) < strings.ToLower(out[j].name)
	})
	return out, nil
}

func countAngo(dir string) int {
	es, err := os.ReadDir(dir)
	if err != nil {
		return 0
	}
	n := 0
	for _, e := range es {
		if !e.IsDir() && strings.HasSuffix(e.Name(), ".ango") {
			n++
		}
	}
	return n
}

// findAngo locates the ango binary: an explicit path, else next to this
// launcher, else on PATH.
func findAngo(explicit string) (string, error) {
	if explicit != "" {
		if st, err := os.Stat(explicit); err != nil || st.IsDir() {
			return "", fmt.Errorf("binary ango tidak ditemukan di %q", explicit)
		}
		return explicit, nil
	}
	if exe, err := os.Executable(); err == nil {
		cand := filepath.Join(filepath.Dir(exe), "ango")
		if st, err := os.Stat(cand); err == nil && !st.IsDir() {
			return cand, nil
		}
	}
	if p, err := exec.LookPath("ango"); err == nil {
		return p, nil
	}
	return "", errors.New("binary ango tidak ditemukan (taruh di samping launcher, atau pakai -ango <path>)")
}

func defaultRoot() string {
	if exe, err := os.Executable(); err == nil {
		return filepath.Join(filepath.Dir(exe), "projects")
	}
	return "projects"
}

// ---- launcher state ----

type button struct {
	label   string
	enabled bool
	action  func()
}

type launcher struct {
	face  *text.GoTextFace
	pixel *ebiten.Image

	root string
	ango string

	projects []project
	sel      int
	scroll   int // first visible project index
	logOff   int // lines scrolled up from the newest log line

	lastClickIdx  int
	lastClickTime time.Time

	mu      sync.Mutex
	lines   []string
	running int
}

func newLauncher(root, ango string) (*launcher, error) {
	src, err := text.NewGoTextFaceSource(bytes.NewReader(goregular.TTF))
	if err != nil {
		return nil, fmt.Errorf("load font: %w", err)
	}
	l := &launcher{
		face:         &text.GoTextFace{Source: src, Size: faceSize},
		pixel:        ebiten.NewImage(1, 1),
		root:         root,
		ango:         ango,
		lastClickIdx: -1,
	}
	l.pixel.Fill(color.White)
	return l, nil
}

func (l *launcher) logf(format string, args ...any) {
	s := fmt.Sprintf(format, args...)
	s = strings.ReplaceAll(strings.ReplaceAll(s, "\r", ""), "\t", "    ")
	l.mu.Lock()
	defer l.mu.Unlock()
	l.lines = append(l.lines, strings.Split(s, "\n")...)
	if len(l.lines) > 2000 {
		l.lines = append([]string(nil), l.lines[500:]...)
	}
}

func (l *launcher) snapshot() (lines []string, running int) {
	l.mu.Lock()
	defer l.mu.Unlock()
	return append([]string(nil), l.lines...), l.running
}

func (l *launcher) addRunning(d int) {
	l.mu.Lock()
	l.running += d
	l.mu.Unlock()
}

func (l *launcher) reload() {
	ps, err := scanProjects(l.root)
	if err != nil {
		l.logf("tidak bisa membaca %s: %v", l.root, err)
	}
	l.projects = ps
	if l.sel >= len(ps) {
		l.sel = len(ps) - 1
	}
	if l.sel < 0 {
		l.sel = 0
	}
	l.ensureVisible()
}

func (l *launcher) selected() (project, bool) {
	if l.sel < 0 || l.sel >= len(l.projects) {
		return project{}, false
	}
	return l.projects[l.sel], true
}

func (l *launcher) visibleItems() int { return listRect.Dy() / itemH }

func (l *launcher) ensureVisible() {
	v := l.visibleItems()
	if l.sel < l.scroll {
		l.scroll = l.sel
	}
	if l.sel >= l.scroll+v {
		l.scroll = l.sel - v + 1
	}
	if l.scroll < 0 {
		l.scroll = 0
	}
}

// ---- actions ----

// start runs the ango binary with args, streaming its output to the log.
func (l *launcher) start(title string, args ...string) {
	cmd := exec.Command(l.ango, args...)
	pr, pw := io.Pipe()
	cmd.Stdout, cmd.Stderr = pw, pw
	l.logf("> %s: %s %s", title, filepath.Base(l.ango), strings.Join(args, " "))
	if err := cmd.Start(); err != nil {
		l.logf("gagal memulai: %v", err)
		return
	}
	l.addRunning(1)

	done := make(chan struct{})
	go func() {
		sc := bufio.NewScanner(pr)
		for sc.Scan() {
			l.logf("%s", sc.Text())
		}
		close(done)
	}()
	go func() {
		err := cmd.Wait()
		pw.Close()
		<-done
		if err != nil {
			l.logf("< %s selesai dengan error: %v", title, err)
		} else {
			l.logf("< %s selesai", title)
		}
		l.addRunning(-1)
	}()
}

func (l *launcher) actLaunch() {
	if p, ok := l.selected(); ok && l.ango != "" {
		l.start("Jalankan "+p.name, "-window", p.dir)
	}
}

func (l *launcher) actCheck() {
	if p, ok := l.selected(); ok && l.ango != "" {
		l.start("Periksa "+p.name, "-check", p.dir)
	}
}

func (l *launcher) actAuto() {
	if p, ok := l.selected(); ok && l.ango != "" {
		l.start("Uji otomatis "+p.name, "-auto", p.dir)
	}
}

func (l *launcher) actOpen() {
	p, ok := l.selected()
	if !ok {
		return
	}
	cmd := exec.Command("xdg-open", p.dir)
	if err := cmd.Start(); err != nil {
		l.logf("xdg-open gagal: %v", err)
		return
	}
	go cmd.Wait()
}

func (l *launcher) actRefresh() {
	name := ""
	if p, ok := l.selected(); ok {
		name = p.name
	}
	l.reload()
	for i, p := range l.projects {
		if p.name == name {
			l.sel = i
		}
	}
	l.ensureVisible()
	l.logf("Daftar proyek dimuat ulang (%d proyek)", len(l.projects))
}

func (l *launcher) buttons() []button {
	hasProj := len(l.projects) > 0
	canRun := hasProj && l.ango != ""
	return []button{
		{"Jalankan", canRun, l.actLaunch},
		{"Periksa Skrip", canRun, l.actCheck},
		{"Uji Otomatis", canRun, l.actAuto},
		{"Buka Folder", hasProj, l.actOpen},
		{"Segarkan (F5)", true, l.actRefresh},
	}
}

func btnRect(i int) image.Rectangle {
	col, row := i/3, i%3
	x := infoX + col*(btnW+btnGapX)
	y := btnTop + row*(btnH+btnGapY)
	return image.Rect(x, y, x+btnW, y+btnH)
}

// ---- ebiten.Game ----

func (l *launcher) Layout(outW, outH int) (int, int) { return winW, winH }

func pressedPoints() []image.Point {
	var pts []image.Point
	if inpututil.IsMouseButtonJustPressed(ebiten.MouseButtonLeft) {
		x, y := ebiten.CursorPosition()
		pts = append(pts, image.Pt(x, y))
	}
	for _, id := range inpututil.AppendJustPressedTouchIDs(nil) {
		x, y := ebiten.TouchPosition(id)
		pts = append(pts, image.Pt(x, y))
	}
	return pts
}

func (l *launcher) Update() error {
	if inpututil.IsKeyJustPressed(ebiten.KeyEscape) {
		return ebiten.Termination
	}

	mx, my := ebiten.CursorPosition()
	if _, wy := ebiten.Wheel(); wy != 0 {
		switch pt := image.Pt(mx, my); {
		case pt.In(listRect):
			l.scroll -= int(wy)
			maxScroll := len(l.projects) - l.visibleItems()
			if maxScroll < 0 {
				maxScroll = 0
			}
			if l.scroll > maxScroll {
				l.scroll = maxScroll
			}
			if l.scroll < 0 {
				l.scroll = 0
			}
		case pt.In(logRect):
			l.logOff += int(wy)
		}
	}

	if n := len(l.projects); n > 0 {
		if inpututil.IsKeyJustPressed(ebiten.KeyArrowDown) && l.sel < n-1 {
			l.sel++
			l.ensureVisible()
		}
		if inpututil.IsKeyJustPressed(ebiten.KeyArrowUp) && l.sel > 0 {
			l.sel--
			l.ensureVisible()
		}
		if inpututil.IsKeyJustPressed(ebiten.KeyEnter) {
			l.actLaunch()
		}
	}
	if inpututil.IsKeyJustPressed(ebiten.KeyF5) {
		l.actRefresh()
	}

	btns := l.buttons()
	for _, p := range pressedPoints() {
		if p.In(listRect) {
			idx := l.scroll + (p.Y-listRect.Min.Y)/itemH
			if idx >= 0 && idx < len(l.projects) {
				l.sel = idx
				// klik dua kali pada proyek yang sama = jalankan
				if idx == l.lastClickIdx && time.Since(l.lastClickTime) < 400*time.Millisecond {
					l.actLaunch()
					l.lastClickIdx = -1
				} else {
					l.lastClickIdx, l.lastClickTime = idx, time.Now()
				}
			}
			continue
		}
		for i, b := range btns {
			if b.enabled && p.In(btnRect(i)) {
				b.action()
			}
		}
	}
	return nil
}

func (l *launcher) Draw(dst *ebiten.Image) {
	dst.Fill(colBG)
	lines, running := l.snapshot()

	// header
	l.drawTextScaled(dst, "Ango Launcher", 24, 12, 1.4, colText)
	l.drawText(dst, l.fit("Folder proyek: "+l.root, 700), 24, 52, colDim)
	if running > 0 {
		l.drawText(dst, fmt.Sprintf("Proses berjalan: %d", running), 900, 24, colText)
	}

	// project list
	l.fillRect(dst, listRect, colPanel)
	if len(l.projects) == 0 {
		l.drawText(dst, "Belum ada proyek.", float64(listRect.Min.X)+14, float64(listRect.Min.Y)+14, colText)
		l.drawText(dst, "Taruh folder game (berisi .ango) di:", float64(listRect.Min.X)+14, float64(listRect.Min.Y)+14+lineH*2, colDim)
		l.drawText(dst, l.fit(l.root, float64(listRect.Dx()-28)), float64(listRect.Min.X)+14, float64(listRect.Min.Y)+14+lineH*3, colDim)
	}
	mx, my := ebiten.CursorPosition()
	for row := 0; row < l.visibleItems(); row++ {
		idx := l.scroll + row
		if idx >= len(l.projects) {
			break
		}
		r := image.Rect(listRect.Min.X, listRect.Min.Y+row*itemH, listRect.Max.X, listRect.Min.Y+(row+1)*itemH)
		switch {
		case idx == l.sel:
			l.fillRect(dst, r, colSel)
		case image.Pt(mx, my).In(r):
			l.fillRect(dst, r, colItem)
		}
		l.drawText(dst, l.fit(l.projects[idx].name, float64(r.Dx()-28)), float64(r.Min.X)+14, float64(r.Min.Y)+(itemH-lineH)/2+2, colText)
	}

	// info
	if p, ok := l.selected(); ok {
		l.drawTextScaled(dst, l.fit(p.name, 600), infoX, 80, 1.5, colText)
		l.drawText(dst, l.fit(p.dir, 680), infoX, 124, colDim)
		l.drawText(dst, fmt.Sprintf("%d berkas .ango", p.files), infoX, 146, colDim)
	}
	if l.ango == "" {
		l.drawText(dst, "Binary ango tidak ditemukan; tombol jalan dinonaktifkan.", infoX, 322-lineH, colDim)
	}

	// buttons
	for i, b := range l.buttons() {
		r := btnRect(i)
		c, tc := colBtn, colText
		switch {
		case !b.enabled:
			c, tc = colOff, colOffTx
		case image.Pt(mx, my).In(r):
			c = colBtnHi
		}
		l.fillRect(dst, r, c)
		tw, _ := text.Measure(b.label, l.face, 0)
		l.drawText(dst, b.label, float64(r.Min.X)+(float64(r.Dx())-tw)/2, float64(r.Min.Y)+(btnH-lineH)/2+2, tc)
	}

	// log
	l.fillRect(dst, logRect, colPanel)
	visible := (logRect.Dy() - 16) / lineH
	maxOff := len(lines) - visible
	if maxOff < 0 {
		maxOff = 0
	}
	if l.logOff > maxOff {
		l.logOff = maxOff
	}
	if l.logOff < 0 {
		l.logOff = 0
	}
	end := len(lines) - l.logOff
	start := end - visible
	if start < 0 {
		start = 0
	}
	for i := start; i < end; i++ {
		y := float64(logRect.Min.Y) + 8 + float64(i-start)*lineH
		l.drawText(dst, l.fit(lines[i], float64(logRect.Dx()-24)), float64(logRect.Min.X)+12, y, colText)
	}
}

// ---- drawing helpers ----

func (l *launcher) fillRect(dst *ebiten.Image, r image.Rectangle, c color.Color) {
	var op ebiten.DrawImageOptions
	op.GeoM.Scale(float64(r.Dx()), float64(r.Dy()))
	op.GeoM.Translate(float64(r.Min.X), float64(r.Min.Y))
	op.ColorScale.ScaleWithColor(c)
	dst.DrawImage(l.pixel, &op)
}

func (l *launcher) drawText(dst *ebiten.Image, s string, x, y float64, c color.Color) {
	l.drawTextScaled(dst, s, x, y, 1, c)
}

func (l *launcher) drawTextScaled(dst *ebiten.Image, s string, x, y, scale float64, c color.Color) {
	op := &text.DrawOptions{}
	op.GeoM.Scale(scale, scale)
	op.GeoM.Translate(x, y)
	op.ColorScale.ScaleWithColor(c)
	text.Draw(dst, s, l.face, op)
}

// fit shortens s with "..." so it is at most maxW pixels wide.
func (l *launcher) fit(s string, maxW float64) string {
	if w, _ := text.Measure(s, l.face, 0); w <= maxW {
		return s
	}
	rs := []rune(s)
	for len(rs) > 0 {
		rs = rs[:len(rs)-1]
		if w, _ := text.Measure(string(rs)+"...", l.face, 0); w <= maxW {
			return string(rs) + "..."
		}
	}
	return ""
}

// ---- main ----

func main() {
	angoFlag := flag.String("ango", "", "path ke binary ango (bawaan: di samping launcher, lalu PATH)")
	flag.Usage = func() {
		fmt.Fprintf(flag.CommandLine.Output(), "usage: ango-launcher [-ango path] [folder-proyek]\n")
		flag.PrintDefaults()
	}
	flag.Parse()

	root := flag.Arg(0)
	if root == "" {
		root = defaultRoot()
	}

	l, err := newLauncher(root, "")
	if err != nil {
		log.Fatal(err)
	}
	if bin, err := findAngo(*angoFlag); err != nil {
		l.logf("%v", err)
	} else {
		l.ango = bin
		l.logf("ango: %s", bin)
	}
	if _, err := os.Stat(root); err != nil {
		l.logf("folder proyek belum ada: %s", root)
		l.logf("buat folder itu, atau jalankan: ango-launcher <folder-proyek>")
	} else {
		l.reload()
		l.logf("%d proyek ditemukan di %s", len(l.projects), root)
	}

	ebiten.SetWindowTitle("Ango Launcher")
	ebiten.SetWindowSize(winW*3/4, winH*3/4)
	ebiten.SetWindowResizingMode(ebiten.WindowResizingModeEnabled)
	if err := ebiten.RunGame(l); err != nil && !errors.Is(err, ebiten.Termination) {
		log.Fatal(err)
	}
}
