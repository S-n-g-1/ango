package script

import "fmt"

// Position is a 1-based line and column. Column counts runes, not bytes.
type Position struct {
	Line   int
	Column int
}

// Span is a half-open range [Start, End) in a source file.
// A zero-width span (Start == End) marks synthetic tokens such as DEDENT.
type Span struct {
	File  string
	Start Position
	End   Position
}

// Error is a positioned error shared by the lexer, parser and compiler.
type Error struct {
	Span Span
	Msg  string
}

func (e *Error) Error() string {
	if e.Span.File == "" {
		return fmt.Sprintf("%d:%d: %s", e.Span.Start.Line, e.Span.Start.Column, e.Msg)
	}
	return fmt.Sprintf("%s:%d:%d: %s", e.Span.File, e.Span.Start.Line, e.Span.Start.Column, e.Msg)
}
