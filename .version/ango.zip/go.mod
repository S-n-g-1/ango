module ango

go 1.22
