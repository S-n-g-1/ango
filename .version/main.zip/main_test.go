package main

import (
	"bufio"
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"ango/engine/game"
)

const choiceScript = `label start
Asep: "Halo"
choice:
    "A":
        Asep: "chose A"
    "B":
        Asep: "chose B"
`

func playSrc(t *testing.T, src, input string, auto bool) string {
	t.Helper()
	prog, err := build("test.ango", src)
	if err != nil {
		t.Fatalf("build: %v", err)
	}
	var out bytes.Buffer
	if err := play(game.New(prog), bufio.NewReader(strings.NewReader(input)), &out, auto); err != nil {
		t.Fatalf("play: %v", err)
	}
	return out.String()
}

func mustContain(t *testing.T, out string, parts ...string) {
	t.Helper()
	for _, p := range parts {
		if !strings.Contains(out, p) {
			t.Errorf("output missing %q:\n%s", p, out)
		}
	}
}

func TestAutoModePicksFirstOption(t *testing.T) {
	out := playSrc(t, choiceScript, "", true)
	mustContain(t, out, "Asep: Halo", "1) A", "2) B", "chose A", "[end]")
	if strings.Contains(out, "chose B") {
		t.Errorf("auto mode must pick the first option:\n%s", out)
	}
}

func TestInteractiveChoice(t *testing.T) {
	out := playSrc(t, choiceScript, "\n2\n\n", false)
	mustContain(t, out, "Asep: chose B", "[end]")
}

func TestBadChoiceInputReprompts(t *testing.T) {
	out := playSrc(t, choiceScript, "\nabc\n9\n1\n\n", false)
	if n := strings.Count(out, "Choose 1-2:"); n != 3 {
		t.Errorf("want 3 prompts, got %d:\n%s", n, out)
	}
	mustContain(t, out, "chose A")
}

func TestEOFQuitsCleanly(t *testing.T) {
	out := playSrc(t, choiceScript, "", false)
	mustContain(t, out, "Asep: Halo")
	if strings.Contains(out, "chose") {
		t.Errorf("must stop when input ends:\n%s", out)
	}
}

func TestDemoScriptRunsToEnd(t *testing.T) {
	src, err := os.ReadFile("../../examples/demo.ango")
	if err != nil {
		t.Fatal(err)
	}
	out := playSrc(t, string(src), "", true)
	mustContain(t, out, "[scene: kelas]", "[show: asep senang left]", "jadi 2", "kepala tegak", "[end]")
}

func TestRunCheck(t *testing.T) {
	dir := t.TempDir()
	good := filepath.Join(dir, "good.ango")
	bad := filepath.Join(dir, "bad.ango")
	os.WriteFile(good, []byte("label start\nend\n"), 0o644)
	os.WriteFile(bad, []byte("label start\njump nowhere\n"), 0o644)

	var out, errOut bytes.Buffer
	if code := run(good, true, false, strings.NewReader(""), &out, &errOut); code != 0 || !strings.Contains(out.String(), "OK") {
		t.Errorf("good script: code=%d out=%q err=%q", code, out.String(), errOut.String())
	}

	out.Reset()
	errOut.Reset()
	if code := run(bad, true, false, strings.NewReader(""), &out, &errOut); code != 1 || !strings.Contains(errOut.String(), "undefined label") {
		t.Errorf("bad script: code=%d err=%q", code, errOut.String())
	}

	errOut.Reset()
	if code := run(filepath.Join(dir, "missing.ango"), true, false, strings.NewReader(""), &out, &errOut); code != 1 {
		t.Errorf("missing file: want code 1, got %d", code)
	}
}
