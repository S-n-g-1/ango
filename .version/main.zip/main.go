// Command ango runs an Ango script in the terminal.
//
//	ango game.ango           play interactively
//	ango -auto game.ango     no prompts; always pick the first option (smoke test)
//	ango -check game.ango    compile only and report errors
package main

import (
	"bufio"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"

	"ango/compiler"
	"ango/engine/game"
	"ango/engine/script"
)

func main() {
	check := flag.Bool("check", false, "compile only; report errors and exit")
	auto := flag.Bool("auto", false, "no prompts: continue at once and pick the first option")
	flag.Usage = func() {
		fmt.Fprintln(os.Stderr, "usage: ango [-check] [-auto] script.ango")
		flag.PrintDefaults()
	}
	flag.Parse()
	if flag.NArg() != 1 {
		flag.Usage()
		os.Exit(2)
	}
	os.Exit(run(flag.Arg(0), *check, *auto, os.Stdin, os.Stdout, os.Stderr))
}

// run returns the process exit code.
func run(path string, check, auto bool, in io.Reader, out, errOut io.Writer) int {
	src, err := os.ReadFile(path)
	if err != nil {
		fmt.Fprintln(errOut, err)
		return 1
	}
	prog, err := build(path, string(src))
	if err != nil {
		report(errOut, err)
		return 1
	}
	if check {
		fmt.Fprintf(out, "%s: OK (%d instructions, %d variables)\n", path, len(prog.Code), len(prog.Vars))
		return 0
	}
	if err := play(game.New(prog), bufio.NewReader(in), out, auto); err != nil {
		report(errOut, err)
		return 1
	}
	return 0
}

func build(path, src string) (*compiler.Program, error) {
	ast, err := script.Parse(path, src)
	if err != nil {
		return nil, err
	}
	return compiler.Compile(ast)
}

func report(w io.Writer, err error) {
	var es compiler.Errors
	if errors.As(err, &es) {
		fmt.Fprintln(w, es.Details())
		return
	}
	fmt.Fprintln(w, err)
}

// play drives the VM until the script ends, input runs out, or an error occurs.
func play(vm *game.VM, in *bufio.Reader, out io.Writer, auto bool) error {
	for {
		ev, err := vm.Next()
		if err != nil {
			return err
		}
		switch ev.Kind {
		case game.EventSay:
			if ev.Speaker != "" {
				fmt.Fprintf(out, "%s: %s\n", ev.Speaker, ev.Text)
			} else {
				fmt.Fprintln(out, ev.Text)
			}
			if !auto && !waitEnter(in) {
				return nil
			}

		case game.EventScene:
			fmt.Fprintf(out, "[scene: %s]\n", ev.Asset)

		case game.EventShow:
			fmt.Fprintf(out, "[show: %s %s %s]\n", ev.Sprite.Character, ev.Sprite.Expression, ev.Sprite.Position)

		case game.EventHide:
			fmt.Fprintf(out, "[hide: %s]\n", ev.Target)

		case game.EventChoice:
			for i, o := range ev.Options {
				fmt.Fprintf(out, "  %d) %s\n", i+1, o)
			}
			idx := 0
			if auto {
				fmt.Fprintln(out, "  > 1")
			} else {
				var ok bool
				if idx, ok = askChoice(in, out, len(ev.Options)); !ok {
					return nil
				}
			}
			if err := vm.Choose(idx); err != nil {
				return err
			}

		case game.EventEnd:
			fmt.Fprintln(out, "[end]")
			return nil
		}
	}
}

// waitEnter blocks for Enter. It returns false when input is exhausted.
func waitEnter(in *bufio.Reader) bool {
	_, err := in.ReadString('\n')
	return err == nil
}

// askChoice re-prompts until it reads a number in 1..n.
// It returns ok=false when input is exhausted.
func askChoice(in *bufio.Reader, out io.Writer, n int) (int, bool) {
	for {
		fmt.Fprintf(out, "Choose 1-%d: ", n)
		line, err := in.ReadString('\n')
		if k, convErr := strconv.Atoi(strings.TrimSpace(line)); convErr == nil && k >= 1 && k <= n {
			return k - 1, true
		}
		if err != nil {
			fmt.Fprintln(out)
			return 0, false
		}
	}
}
