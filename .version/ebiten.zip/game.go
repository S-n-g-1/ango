package ebitengine

import (
	"bytes"
	"fmt"
	"hash/fnv"
	"image"
	"image/color"
	"io/fs"
	"math"
	"strings"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
	"github.com/hajimehoshi/ebiten/v2/text/v2"
	"golang.org/x/image/font/gofont/goregular"
)

// Logical resolution. The window can be any size; Ebitengine scales it.
const (
	screenW = 1280
	screenH = 720

	fontSize = 26
	lineH    = 34
	maxLines = 4

	boxX, boxY, boxW, boxH = 40, 520, 1200, 170

	choiceW, choiceH, choiceGap = 720, 56, 16

	spriteH = 600.0 // sprites are scaled to this height
)

var (
	colWhite = color.NRGBA{255, 255, 255, 255}
	colBox   = color.NRGBA{0, 0, 0, 190}
	colPlate = color.NRGBA{30, 30, 70, 230}
	colBtn   = color.NRGBA{20, 20, 40, 220}
	colBtnHi = color.NRGBA{70, 70, 140, 240}
)

// Options configures Run.
type Options struct {
	Title  string
	Assets fs.FS // rooted at the assets dir; may be nil (placeholders only)
}

// Run opens a window and plays sess until the script ends or the window closes.
func Run(sess Session, opts Options) error {
	src, err := text.NewGoTextFaceSource(bytes.NewReader(goregular.TTF))
	if err != nil {
		return fmt.Errorf("load font: %w", err)
	}
	g := &Game{
		sess:   sess,
		assets: newAssets(opts.Assets),
		face:   &text.GoTextFace{Source: src, Size: fontSize},
		pixel:  ebiten.NewImage(1, 1),
	}
	g.pixel.Fill(color.White)
	g.sync()

	title := opts.Title
	if title == "" {
		title = "Ango"
	}
	ebiten.SetWindowTitle(title)
	ebiten.SetWindowSize(screenW*3/4, screenH*3/4)
	ebiten.SetWindowResizingMode(ebiten.WindowResizingModeEnabled)
	return ebiten.RunGame(g)
}

// Game implements ebiten.Game.
type Game struct {
	sess   Session
	assets *assets
	face   *text.GoTextFace
	pixel  *ebiten.Image // 1x1 white, scaled to draw rectangles

	view  View
	lines []string // wrapped dialogue for the current view
}

// sync re-reads the view; call it after every Advance/Choose.
func (g *Game) sync() {
	g.view = g.sess.View()
	g.lines = wrap(g.view.Text, g.face, boxW-56)
}

func (g *Game) Layout(outW, outH int) (int, int) { return screenW, screenH }

func (g *Game) Update() error {
	switch {
	case g.view.Ended:
		if continuePressed() {
			return ebiten.Termination
		}
	case len(g.view.Choices) > 0:
		if i := g.pickedChoice(); i >= 0 {
			if err := g.sess.Choose(i); err != nil {
				return err
			}
			g.sync()
		}
	default:
		if continuePressed() {
			if err := g.sess.Advance(); err != nil {
				return err
			}
			g.sync()
		}
	}
	return nil
}

// --- input ---

// justPressedPoints returns positions (logical coords) of new clicks/touches.
func justPressedPoints() []image.Point {
	var pts []image.Point
	if inpututil.IsMouseButtonJustPressed(ebiten.MouseButtonLeft) {
		x, y := ebiten.CursorPosition()
		pts = append(pts, image.Pt(x, y))
	}
	for _, id := range inpututil.AppendJustPressedTouchIDs(nil) {
		x, y := ebiten.TouchPosition(id)
		pts = append(pts, image.Pt(x, y))
	}
	return pts
}

func continuePressed() bool {
	if inpututil.IsKeyJustPressed(ebiten.KeySpace) || inpututil.IsKeyJustPressed(ebiten.KeyEnter) {
		return true
	}
	return len(justPressedPoints()) > 0
}

// pickedChoice returns the chosen index (click, touch or keys 1-9) or -1.
func (g *Game) pickedChoice() int {
	rects := choiceRects(len(g.view.Choices))
	for _, p := range justPressedPoints() {
		for i, r := range rects {
			if p.In(r) {
				return i
			}
		}
	}
	for i := range rects {
		if i > 8 {
			break
		}
		if inpututil.IsKeyJustPressed(ebiten.KeyDigit1 + ebiten.Key(i)) {
			return i
		}
	}
	return -1
}

// choiceRects lays out n buttons centered in the area above the textbox.
func choiceRects(n int) []image.Rectangle {
	total := n*choiceH + (n-1)*choiceGap
	top := (boxY - total) / 2
	if top < 8 {
		top = 8
	}
	x := (screenW - choiceW) / 2
	rects := make([]image.Rectangle, n)
	for i := range rects {
		y := top + i*(choiceH+choiceGap)
		rects[i] = image.Rect(x, y, x+choiceW, y+choiceH)
	}
	return rects
}

// --- drawing ---

func (g *Game) Draw(screen *ebiten.Image) {
	screen.Fill(color.NRGBA{16, 16, 24, 255})
	g.drawBackground(screen)
	for _, sp := range g.view.Sprites {
		g.drawSprite(screen, sp)
	}
	g.drawDialogue(screen)
	switch {
	case g.view.Ended:
		g.drawCentered(screen, "Selesai - klik atau tekan Spasi untuk keluar", screenH/2)
	case len(g.view.Choices) > 0:
		g.drawChoices(screen)
	}
}

func (g *Game) drawBackground(dst *ebiten.Image) {
	name := g.view.Background
	if name == "" {
		return
	}
	img := g.assets.background(name)
	if img == nil {
		bg := tint(name, 255)
		bg.R, bg.G, bg.B = bg.R/3, bg.G/3, bg.B/3
		g.fillRect(dst, 0, 0, screenW, screenH, bg)
		g.drawText(dst, "[background: "+name+"]", 24, 20, colWhite)
		return
	}
	b := img.Bounds()
	s := math.Max(screenW/float64(b.Dx()), screenH/float64(b.Dy())) // cover
	var op ebiten.DrawImageOptions
	op.GeoM.Scale(s, s)
	op.GeoM.Translate((screenW-float64(b.Dx())*s)/2, (screenH-float64(b.Dy())*s)/2)
	op.Filter = ebiten.FilterLinear
	dst.DrawImage(img, &op)
}

func spriteCenterX(pos string) float64 {
	switch pos {
	case "left":
		return screenW * 0.2
	case "right":
		return screenW * 0.8
	default:
		return screenW * 0.5
	}
}

func (g *Game) drawSprite(dst *ebiten.Image, sp Sprite) {
	cx := spriteCenterX(sp.Pos)
	if img := g.assets.sprite(sp.Char, sp.Expr); img != nil {
		b := img.Bounds()
		s := spriteH / float64(b.Dy())
		var op ebiten.DrawImageOptions
		op.GeoM.Translate(-float64(b.Dx())/2, -float64(b.Dy())) // anchor bottom-center
		op.GeoM.Scale(s, s)
		op.GeoM.Translate(cx, screenH)
		op.Filter = ebiten.FilterLinear
		dst.DrawImage(img, &op)
		return
	}
	// placeholder: colored block labeled with character and expression
	const w, h = 260.0, 520.0
	g.fillRect(dst, cx-w/2, screenH-h, w, h, tint(sp.Char, 235))
	g.drawText(dst, sp.Char, cx-w/2+16, screenH-h+16, colWhite)
	g.drawText(dst, sp.Expr, cx-w/2+16, screenH-h+52, colWhite)
}

func (g *Game) drawDialogue(dst *ebiten.Image) {
	if g.view.Text == "" && g.view.Speaker == "" {
		return
	}
	g.fillRect(dst, boxX, boxY, boxW, boxH, colBox)
	if sp := g.view.Speaker; sp != "" {
		tw, _ := text.Measure(sp, g.face, 0)
		g.fillRect(dst, boxX+20, boxY-44, tw+40, 44, colPlate)
		g.drawText(dst, sp, boxX+40, boxY-44+5, colWhite)
	}
	for i, ln := range g.lines {
		if i >= maxLines {
			break
		}
		g.drawText(dst, ln, boxX+28, boxY+20+float64(i)*lineH, colWhite)
	}
}

func (g *Game) drawChoices(dst *ebiten.Image) {
	mx, my := ebiten.CursorPosition()
	for i, r := range choiceRects(len(g.view.Choices)) {
		c := colBtn
		if image.Pt(mx, my).In(r) {
			c = colBtnHi
		}
		g.fillRect(dst, float64(r.Min.X), float64(r.Min.Y), float64(r.Dx()), float64(r.Dy()), c)
		label := fmt.Sprintf("%d) %s", i+1, g.view.Choices[i])
		g.drawText(dst, label, float64(r.Min.X)+24, float64(r.Min.Y)+(choiceH-lineH)/2+2, colWhite)
	}
}

func (g *Game) drawCentered(dst *ebiten.Image, s string, y float64) {
	tw, _ := text.Measure(s, g.face, 0)
	g.fillRect(dst, (screenW-tw)/2-20, y-10, tw+40, lineH+20, colBox)
	g.drawText(dst, s, (screenW-tw)/2, y, colWhite)
}

// --- helpers ---

func (g *Game) fillRect(dst *ebiten.Image, x, y, w, h float64, c color.Color) {
	var op ebiten.DrawImageOptions
	op.GeoM.Scale(w, h)
	op.GeoM.Translate(x, y)
	op.ColorScale.ScaleWithColor(c)
	dst.DrawImage(g.pixel, &op)
}

func (g *Game) drawText(dst *ebiten.Image, s string, x, y float64, c color.Color) {
	op := &text.DrawOptions{}
	op.GeoM.Translate(x, y)
	op.ColorScale.ScaleWithColor(c)
	text.Draw(dst, s, g.face, op)
}

// wrap breaks s into lines no wider than maxW, on spaces. Explicit "\n" is kept.
func wrap(s string, face text.Face, maxW float64) []string {
	if s == "" {
		return nil
	}
	var lines []string
	for _, para := range strings.Split(s, "\n") {
		cur := ""
		for _, word := range strings.Fields(para) {
			try := word
			if cur != "" {
				try = cur + " " + word
			}
			if w, _ := text.Measure(try, face, 0); w > maxW && cur != "" {
				lines = append(lines, cur)
				cur = word
			} else {
				cur = try
			}
		}
		lines = append(lines, cur)
	}
	return lines
}

// tint gives a stable color per name, for placeholders.
func tint(name string, alpha uint8) color.NRGBA {
	h := fnv.New32a()
	h.Write([]byte(name))
	v := h.Sum32()
	return color.NRGBA{
		R: 60 + uint8(v%140),
		G: 60 + uint8((v>>8)%140),
		B: 60 + uint8((v>>16)%140),
		A: alpha,
	}
}
