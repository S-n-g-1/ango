package ebitengine

import (
	"image"
	_ "image/jpeg" // register decoders
	_ "image/png"
	"io/fs"
	"log"
	"path"

	"github.com/hajimehoshi/ebiten/v2"
)

// assets loads images from an fs.FS rooted at the assets directory
// (backgrounds/, characters/, audio/). A nil result means "not found" and
// the caller draws a placeholder instead, so scripts run without art.
type assets struct {
	fsys  fs.FS
	cache map[string]*ebiten.Image // nil value = known missing
}

func newAssets(fsys fs.FS) *assets {
	return &assets{fsys: fsys, cache: map[string]*ebiten.Image{}}
}

// background: `scene "kelas"` -> backgrounds/kelas(.png|.jpg)
func (a *assets) background(name string) *ebiten.Image {
	return a.load(
		path.Join("backgrounds", name),
		path.Join("backgrounds", name+".png"),
		path.Join("backgrounds", name+".jpg"),
	)
}

// sprite: `show asep senang` -> characters/asep_senang.png,
// characters/asep/senang.png or characters/asep.png
func (a *assets) sprite(char, expr string) *ebiten.Image {
	return a.load(
		path.Join("characters", char+"_"+expr+".png"),
		path.Join("characters", char, expr+".png"),
		path.Join("characters", char+".png"),
	)
}

// load tries each candidate path in order; the first is the cache key.
func (a *assets) load(candidates ...string) *ebiten.Image {
	key := candidates[0]
	if img, ok := a.cache[key]; ok {
		return img
	}
	var img *ebiten.Image
	for _, p := range candidates {
		if img = a.decode(p); img != nil {
			break
		}
	}
	if img == nil {
		log.Printf("ebitengine: asset not found: %s (using placeholder)", key)
	}
	a.cache[key] = img
	return img
}

func (a *assets) decode(p string) *ebiten.Image {
	if a.fsys == nil {
		return nil
	}
	f, err := a.fsys.Open(p)
	if err != nil {
		return nil
	}
	defer f.Close()
	src, _, err := image.Decode(f)
	if err != nil {
		log.Printf("ebitengine: decode %s: %v", p, err)
		return nil
	}
	return ebiten.NewImageFromImage(src)
}
