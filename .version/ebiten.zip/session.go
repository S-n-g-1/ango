// Package ebitengine is the Ebitengine presentation backend for Ango.
//
// It knows nothing about the compiler, VM or GameState. It renders a View
// and reports player input back through a Session; a small adapter (in
// cmd/ango) bridges Session to engine/game.
package ebitengine

// Sprite is one character currently shown on screen.
type Sprite struct {
	Char string // character id, e.g. "asep"
	Expr string // expression, e.g. "senang"
	Pos  string // "left", "center" (default) or "right"
}

// View is the presentation snapshot the backend renders each frame.
type View struct {
	Background string   // asset name from `scene`, "" = none
	Sprites    []Sprite // in draw order (last is on top)
	Speaker    string   // "" = narration
	Text       string   // current dialogue line, "" = no textbox
	Choices    []string // non-empty = waiting for a choice
	Ended      bool     // script finished
}

// Session is what the backend needs from the engine.
type Session interface {
	// View returns the current presentation state.
	View() View
	// Advance moves past the current line (called on click/space/enter).
	Advance() error
	// Choose picks choice index i (0-based) while Choices is non-empty.
	Choose(i int) error
}
